package com.paymentchain.billing;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BasicApplicationTests {

	@Test
	public void contextLoads() {
	}

}
